<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="style4.css">
</head>
<body>
    
           
    <form method="post" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'];?>">
    <h1>Student Info</h1>
        <label for="id">Enter Student ID:</label>
        <input type="number" id="studid" name="studid" required>
        <input type="submit" name="sub" value="SUBMIT">
    </form>

</body>

</html>
<?php
 error_reporting(0);
if (isset($_POST['sub'])){
    $id=$_POST["studid"];
    $command_exec = escapeshellcmd("python studentview.py $id");
    $str_output = shell_exec($command_exec);
    
    $ar=explode(" ",$str_output);
    if (!is_numeric($ar[0])){
        echo "<cetner>";
        echo "<link rel='stylesheet' href='style.css'>";
        exit("<h1>Unable to Verify Student ID</h1>");
    }
    $id=$ar[0];
    $c=3;
    $name=$ar[$c];
    $c=$c+1;
    #echo is_numeric("119");
    while (is_numeric($ar[$c])!=true){
        $name=$name." ".$ar[$c];
        $c=$c+1;   
    }
    
    
    $total=$ar[$c];
    $c=$c+3;
    $standing=$ar[$c];
    $c=$c+3;
    $major=$ar[$c];
    $c=$c+1;
    while (is_numeric($ar[$c])!=true){
        $major=$major." ".$ar[$c];
        $c=$c+1;    
    }
    $year=$ar[$c];
    $c=$c+3;
    $starting_yr=$ar[$c];
    $c=$c+3;
    $lst_at_time=$ar[$c]." ".$ar[$c+1];
    
    echo "<link rel='stylesheet' href='style3.css'>";
    echo "<center>";
    echo "<h1> Student Information </h1>";
    
    echo "<img src='Images/$id.jpg'></img>";
    echo "<br>";
    echo "ID : ",$id;
    echo "<br>";
    echo "Name : ",$name;
    echo "<br>";
    echo "Total Attendance : ",$total;
    echo "<br>";
    
    echo "Major : ",$major;
    echo "<br>";
    echo "Standing : ",$standing;
    echo "<br>";
    echo "Year : ",$year;
    echo "<br>";
    echo "Starting Year : ",$starting_yr;
    echo "<br>";
    echo "Last Attendance Time : ",$lst_at_time;
    echo "<br> <br> <br>";
    
    

}
?>